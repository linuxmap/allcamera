// -*- C++ -*-

//==========================================================================
/**
 *  @file    Functor_String.h
 *
 *   Class template specializations for ACE_*String types implementing
 *   function objects that are used in  various places in ATC. They
 *   could be placed in Functor.h. But we don't want to couple string
 *   types to the rest of ACE+TAO. Hence they are placed in a separate
 *   file.
 */
//==========================================================================
#ifndef ACE_FUNCTOR_STRING_H
#define ACE_FUNCTOR_STRING_H
#include /**/ "ace/pre.h"

#include /**/ "ace/config-all.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#include /**/ "ace/ACE_export.h"
#include "ace/SStringfwd.h"
#include <string>

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

////////////////////////////////////////////////////////////
// STL-style Functor Classes and Template Specializations //
////////////////////////////////////////////////////////////

// Forward declaration since we are going to specialize that template
// here. The template itself requires this file so every user of the
// template should also see the specialization.
template <class TYPE> class ACE_Hash;
template <class TYPE> class ACE_Equal_To;
template <class TYPE> class ACE_Less_Than;

/**
 * @brief Function object for determining whether two ACE_CStrings are
 * equal.
 */
template<>
class ACE_Export ACE_Equal_To<ACE_CString>
{
public:
  int operator () (const ACE_CString &lhs,
                   const ACE_CString &rhs) const;
};


/**
 * @brief Function object for hashing a ACE_CString
 */
template<>
class ACE_Export ACE_Hash<ACE_CString>
{
public:
  /// Calls ACE::hash_pjw
  unsigned long operator () (const ACE_CString &lhs) const;
};


/**
 * @brief Function object for determining whether the first const string
 * is less than the second const string.
 */
template<>
class ACE_Export ACE_Less_Than<ACE_CString>
{
public:
  /// Simply calls ACE_OS::strcmp
  int operator () (const ACE_CString &lhs,
                   const ACE_CString &rhs) const;
};

/**
 * @brief Function object for determining whether two std::strings are
 * equal.
 */
template<>
class ACE_Export ACE_Equal_To<std::string>
{
public:
  int operator () (const std::string &lhs,
                   const std::string &rhs) const;
};


/**
 * @brief Function object for hashing a std::string
 */
template<>
class ACE_Export ACE_Hash<std::string>
{
public:
  /// Calls ACE::hash_pjw
  unsigned long operator () (const std::string &lhs) const;
};


/**
 * @brief Function object for determining whether the first const string
 * is less than the second const string.
 */
template<>
class ACE_Export ACE_Less_Than<std::string>
{
public:
  /// Simply calls std::string::compare
  int operator () (const std::string &lhs,
                   const std::string &rhs) const;
};


#if defined (ACE_USES_WCHAR)

/**
 * @brief Function object for determining whether two ACE_WStrings are
 * equal.
 */
template<>
class ACE_Export ACE_Equal_To<ACE_WString>
{
public:
  int operator () (const ACE_WString &lhs,
                   const ACE_WString &rhs) const;
};


/**
 * @brief Function object for hashing a ACE_WString
 */
template<>
class ACE_Export ACE_Hash<ACE_WString>
{
public:
  /// Calls ACE::hash_pjw
  unsigned long operator () (const ACE_WString &lhs) const;
};

/**
 * @brief Function object for determining whether the first const wstring
 * is less than the second const wstring.
 */
template<>
class ACE_Export ACE_Less_Than<ACE_WString>
{
public:
  /// Simply calls ACE_OS::strcmp
  int operator () (const ACE_WString &lhs,
                   const ACE_WString &rhs) const;
};

#endif /*ACE_USES_WCHAR*/

ACE_END_VERSIONED_NAMESPACE_DECL

#if defined (__ACE_INLINE__)
#include "ace/Functor_String.inl"
#endif /* __ACE_INLINE__ */

#include /**/ "ace/post.h"
#endif /*ACE_FUNCTOR_STRING_H*/
