/**
 * @file Copy_Disabled.cpp
 *
 * @author Carlos O'Ryan <coryan@uci.edu>
 */

#include "ace/Copy_Disabled.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Copy_Disabled::ACE_Copy_Disabled (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
